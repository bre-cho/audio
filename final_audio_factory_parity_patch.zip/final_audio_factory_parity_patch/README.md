# FINAL AUDIO FACTORY PARITY PATCH

## Mục tiêu

Khóa parity xuyên suốt:

```txt
Route ghi workflow nào
→ Worker chạy đúng workflow đó
→ Factory validate đúng contract đó
→ DB lưu đúng artifact đó
→ CI chứng minh đủ 4–5 workflow đó
```

## File thay đổi

```txt
backend/app/audio_factory/workflow_router.py
backend/app/workers/audio_tasks.py
backend/app/workers/clone_tasks.py
backend/app/services/job_service.py
backend/tests/test_audio_route_task_mapping.py
backend/tests/test_audio_worker_artifact_guard.py
scripts/ci/seed_clone_preview_voice.py
.github/workflows/audio-master-verify.yml
```

## Apply nhanh

Cách 1: copy toàn bộ `changed_files/` đè vào repo.

Cách 2: apply diff:

```bash
git apply FINAL_AUDIO_FACTORY_PARITY_PATCH.diff
```

## Verify

```bash
python -m compileall backend/app scripts backend/tests
```

Nếu dependencies đã cài:

```bash
cd backend
PYTHONPATH=. pytest -q tests/test_audio_route_task_mapping.py tests/test_audio_worker_artifact_guard.py
```

Nếu chạy CI stack:

```bash
docker compose up -d postgres redis api worker
python scripts/ci/wait_for_stack.py 300
PYTHONPATH=backend python scripts/migrations/audio_factory_schema.py
PYTHONPATH=backend python scripts/ci/audio_schema_guard.py
python scripts/ci/e2e_conversation.py
PYTHONPATH=backend python scripts/ci/seed_clone_preview_voice.py
python scripts/ci/e2e_clone_preview.py
PYTHONPATH=backend python scripts/ci/artifact_checksum_verify.py
python scripts/ci/factory_report_merge.py
```

## Nội dung chính

1. `WorkflowRouter` support `TTS_GENERATE`.
2. Conversation workflow chấp nhận `conversation_turns`, `script`, hoặc `text` để không fail legacy job.
3. `audio_tasks.py` đọc `workflow_type` từ DB làm source of truth.
4. `clone_tasks.py` cũng đọc `workflow_type` từ DB.
5. Runtime JSON ghi `workflow_type` để trace end-to-end.
6. Retry job service routing theo `workflow_type` trước, không chỉ `job_type`.
7. CI seed voice trước clone preview E2E để tránh lỗi FK giả.
8. Test chứng minh `/tts/generate` lưu `tts_generate` và worker chạy đúng workflow từ DB.
