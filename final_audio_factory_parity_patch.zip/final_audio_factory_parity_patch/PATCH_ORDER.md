# Patch Order

## P0 — Router parity

Apply:

```txt
backend/app/audio_factory/workflow_router.py
```

Verify:

```bash
python -m compileall backend/app/audio_factory
```

## P1 — Worker parity

Apply:

```txt
backend/app/workers/audio_tasks.py
backend/app/workers/clone_tasks.py
```

Verify:

```bash
python -m compileall backend/app/workers
```

## P2 — Retry parity

Apply:

```txt
backend/app/services/job_service.py
```

Verify retry manually for:

```txt
tts_generate
tts_preview
narration
conversation
clone_preview
clone
```

## P3 — CI clone preview seed

Apply:

```txt
scripts/ci/seed_clone_preview_voice.py
.github/workflows/audio-master-verify.yml
```

## P4 — Tests

Apply:

```txt
backend/tests/test_audio_route_task_mapping.py
backend/tests/test_audio_worker_artifact_guard.py
```
