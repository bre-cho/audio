# BUILD REPO-READY AUDIO SYSTEM PACK

This pack contains:
- docs/module_tree.md
- docs/schema.sql
- docs/openapi.yaml
- docs/service_wiring.md
- docs/merge_order.md
- docs/patch_map.md

Use order:
1. Read `merge_order.md`
2. Apply `schema.sql` through migrations, not raw production DB edits
3. Wire routes and services from `patch_map.md`
4. Implement adapters behind `providers/base.py`
5. Only then build frontend pages around the API
