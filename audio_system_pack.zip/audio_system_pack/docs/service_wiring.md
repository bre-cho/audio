# Audio AI System — Service Wiring

## 1. Route → Service → Repository

### TTS
- `api/tts.py`
  - validates request schema
  - calls `tts_service.queue_generate()`
- `services/tts_service.py`
  - estimates credits
  - reserves credits
  - creates job row
  - sends Celery task
- `repositories/job_repo.py`
  - persists `audio_jobs`
- `repositories/credit_repo.py`
  - inserts reserve/settlement/refund rows

### Conversation
- `api/conversation.py`
  - parses incoming dialogue block or structured script
  - calls `conversation_service.queue_generate()`
- `services/conversation_service.py`
  - splits speakers
  - maps provider/voice per segment
  - creates `conversation_segments`
  - schedules generation + merge
- `services/audio_merge_service.py`
  - concatenates segment outputs
  - inserts pauses
  - normalizes loudness
  - stores final merged output

### Voice Clone
- `api/voice_clone.py`
  - handles upload metadata + clone create request
- `services/voice_clone_service.py`
  - validates consent
  - inspects sample duration/format
  - optional denoise
  - delegates to provider adapter
  - creates private cloned `voice`
- `repositories/voice_repo.py`
  - creates and updates `voices` and `voice_samples`

### Voice Library
- `api/voices.py`
  - list/filter/get/update/delete
- `services/voice_library_service.py`
  - resolves system vs cloned voices
  - merges provider metadata with local filters
- `repositories/voice_repo.py`
  - query logic for source type, gender, language, tags

### Projects / Studio
- `api/projects.py`
  - CRUD project and scripts
  - batch-generate/export endpoints
- `services/project_service.py`
  - owns project lifecycle
  - links outputs to projects
  - orchestrates batch jobs

### Billing
- `api/billing.py`
  - balance / ledger / estimate
- `services/billing_service.py`
  - reads ledger summary
  - uses `pricing.py`
- `services/usage_service.py`
  - records char / second / request consumption

---

## 2. Provider Router Contract

`services/provider_router.py` is the only module allowed to choose a provider.

### Inputs
- explicit provider from UI
- selected voice
- model requested
- job type
- routing policy

### Outputs
- provider adapter instance
- normalized payload
- normalized capability metadata

### Rules
1. If a user explicitly selects a provider, try that first.
2. If a voice belongs to a provider, prefer its native provider.
3. If the preferred provider is degraded, use fallback only if capability is compatible.
4. Never let route handlers know vendor-specific payload details.

---

## 3. Worker Wiring

### `workers/audio_tasks.py`
- `generate_tts(job_id)`
- `generate_conversation_segment(segment_id)`
- `finalize_conversation_merge(job_id)`
- `export_project_bundle(project_id)`

### `workers/clone_tasks.py`
- `clone_voice(job_id)`
- `generate_clone_preview(job_id)`

### `workers/housekeeping_tasks.py`
- delete expired previews
- reconcile incomplete jobs
- verify storage orphan records

---

## 4. Storage Flow

`core/storage.py`
- upload local temp file to object storage
- return `storage_key`
- optionally issue signed/public URL

### Storage key pattern
- `users/{user_id}/voices/{voice_id}/samples/{file}`
- `users/{user_id}/projects/{project_id}/jobs/{job_id}/final.mp3`
- `users/{user_id}/projects/{project_id}/exports/{timestamp}.zip`

---

## 5. Credit Settlement Pattern

### Reserve-first
1. estimate credits
2. write reserve row
3. create job
4. queue task

### Settle on completion
1. compute actual usage
2. write usage event
3. settle reserved credits
4. refund unused credits if actual < reserved

### Fail-safe
- provider/auth/config failure: full refund
- partial conversation failure: settle per completed segment + refund the rest

---

## 6. Minimal dependency graph

- `api/*` depends on `schemas/*` and `services/*`
- `services/*` depends on `repositories/*`, `providers/*`, `core/*`, `utils/*`
- `providers/*` depends only on `core/config.py` and HTTP client helpers
- `workers/*` depends on `services/*`
- `repositories/*` depends only on `models/*` and DB session layer

This keeps vendor logic, business logic, and persistence separate enough to replace providers later without ripping routes apart.
