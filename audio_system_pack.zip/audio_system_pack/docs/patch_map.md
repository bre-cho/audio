# Audio AI System — Patch Map

## Backend patch map

### `backend/app/models/`
Add:
- `provider.py`
- `voice.py`
- `voice_sample.py`
- `project.py`
- `script_asset.py`
- `audio_job.py`
- `audio_output.py`
- `conversation_segment.py`
- `usage_event.py`
- `credit_ledger.py`
- `webhook_event.py`

### `backend/app/schemas/`
Add:
- `tts.py`
- `conversation.py`
- `voice_clone.py`
- `voices.py`
- `projects.py`
- `jobs.py`
- `billing.py`

### `backend/app/api/`
Add routers:
- `tts.py`
- `conversation.py`
- `voice_clone.py`
- `voices.py`
- `projects.py`
- `jobs.py`
- `billing.py`

Patch `main.py`:
- register all new routers under `/api/v1`

### `backend/app/services/`
Add:
- `provider_router.py`
- `tts_service.py`
- `conversation_service.py`
- `voice_clone_service.py`
- `voice_library_service.py`
- `project_service.py`
- `audio_merge_service.py`
- `usage_service.py`
- `billing_service.py`
- `moderation_service.py`

### `backend/app/providers/`
Add:
- `base.py`
- `elevenlabs.py`
- `minimax.py`
- `internal_genvoice.py`

### `backend/app/workers/`
Add:
- `celery_app.py`
- `audio_tasks.py`
- `clone_tasks.py`
- `housekeeping_tasks.py`

### `backend/app/utils/`
Add:
- `text_normalizer.py`
- `script_parser.py`
- `ffmpeg_utils.py`
- `hash_utils.py`

### `backend/alembic/versions/`
Add migration chain in this order:
1. providers + voices
2. projects + script_assets
3. audio_jobs + outputs + segments
4. credit_ledger + usage_events + webhook_events

---

## Frontend patch map

### `frontend/app/`
Add pages:
- `tts/page.tsx`
- `conversation/page.tsx`
- `voice-changer/page.tsx`
- `voice-library/page.tsx`
- `studio/page.tsx`
- `projects/[id]/page.tsx`
- `history/page.tsx`
- `billing/page.tsx`

### `frontend/components/audio/`
Add:
- `TTSComposer.tsx`
- `ConversationComposer.tsx`
- `AudioPlayerCard.tsx`
- `WaveformPreview.tsx`

### `frontend/components/provider/`
Add:
- `ProviderSelector.tsx`
- `ModelSelector.tsx`
- `ProviderHealthBadge.tsx`

### `frontend/components/voices/`
Add:
- `VoicePickerModal.tsx`
- `VoiceFilterBar.tsx`
- `VoiceCard.tsx`
- `CloneVoiceModal.tsx`

### `frontend/components/jobs/`
Add:
- `JobStatusPill.tsx`
- `JobList.tsx`
- `RetryJobButton.tsx`

### `frontend/components/studio/`
Add:
- `ProjectGrid.tsx`
- `ProjectScriptsPanel.tsx`
- `BatchGenerateButton.tsx`
- `ProjectOutputsTable.tsx`

### `frontend/lib/`
Add:
- `api.ts`
- `audio.ts`
- `jobs.ts`
- `voices.ts`
- `billing.ts`

---

## Infra patch map

### `infra/docker-compose.yml`
Ensure services exist:
- postgres
- redis
- minio or s3-compatible storage
- api
- worker
- beat
- frontend

### env vars
Add:
- `ELEVENLABS_API_KEY`
- `MINIMAX_API_KEY`
- `STORAGE_BUCKET`
- `REDIS_URL`
- `DATABASE_URL`
- `SIGNED_URL_TTL_SECONDS`
- `DEFAULT_PROVIDER`
