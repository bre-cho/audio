# Audio AI System — Repo-Ready Module Tree

```text
audio-ai-system/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth.py
│   │   │   ├── tts.py
│   │   │   ├── conversation.py
│   │   │   ├── voice_clone.py
│   │   │   ├── voices.py
│   │   │   ├── projects.py
│   │   │   ├── jobs.py
│   │   │   ├── billing.py
│   │   │   └── admin.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   ├── security.py
│   │   │   ├── credits.py
│   │   │   ├── pricing.py
│   │   │   └── storage.py
│   │   ├── models/
│   │   │   ├── user.py
│   │   │   ├── provider.py
│   │   │   ├── voice.py
│   │   │   ├── voice_sample.py
│   │   │   ├── project.py
│   │   │   ├── script_asset.py
│   │   │   ├── audio_job.py
│   │   │   ├── audio_output.py
│   │   │   ├── conversation_segment.py
│   │   │   ├── usage_event.py
│   │   │   ├── credit_ledger.py
│   │   │   └── webhook_event.py
│   │   ├── schemas/
│   │   │   ├── auth.py
│   │   │   ├── tts.py
│   │   │   ├── conversation.py
│   │   │   ├── voice_clone.py
│   │   │   ├── voices.py
│   │   │   ├── projects.py
│   │   │   ├── jobs.py
│   │   │   └── billing.py
│   │   ├── repositories/
│   │   │   ├── voice_repo.py
│   │   │   ├── project_repo.py
│   │   │   ├── job_repo.py
│   │   │   ├── output_repo.py
│   │   │   └── credit_repo.py
│   │   ├── services/
│   │   │   ├── provider_router.py
│   │   │   ├── tts_service.py
│   │   │   ├── conversation_service.py
│   │   │   ├── voice_clone_service.py
│   │   │   ├── voice_library_service.py
│   │   │   ├── project_service.py
│   │   │   ├── audio_merge_service.py
│   │   │   ├── waveform_service.py
│   │   │   ├── usage_service.py
│   │   │   ├── billing_service.py
│   │   │   └── moderation_service.py
│   │   ├── providers/
│   │   │   ├── base.py
│   │   │   ├── elevenlabs.py
│   │   │   ├── minimax.py
│   │   │   └── internal_genvoice.py
│   │   ├── workers/
│   │   │   ├── celery_app.py
│   │   │   ├── audio_tasks.py
│   │   │   ├── clone_tasks.py
│   │   │   └── housekeeping_tasks.py
│   │   ├── utils/
│   │   │   ├── text_normalizer.py
│   │   │   ├── script_parser.py
│   │   │   ├── ffmpeg_utils.py
│   │   │   └── hash_utils.py
│   │   └── main.py
│   ├── alembic/
│   └── tests/
├── frontend/
│   ├── app/
│   │   ├── tts/
│   │   ├── conversation/
│   │   ├── voice-changer/
│   │   ├── voice-library/
│   │   ├── studio/
│   │   ├── projects/[id]/
│   │   ├── history/
│   │   └── billing/
│   ├── components/
│   │   ├── audio/
│   │   ├── provider/
│   │   ├── voices/
│   │   ├── jobs/
│   │   └── studio/
│   └── lib/
├── infra/
│   ├── docker-compose.yml
│   ├── nginx/
│   └── monitoring/
└── docs/
    ├── module_tree.md
    ├── schema.sql
    ├── openapi.yaml
    ├── service_wiring.md
    ├── merge_order.md
    └── patch_map.md
```

## Notes

- `providers/` is a hard isolation layer. Do not call vendor APIs directly from routes or services.
- `audio_jobs` is the execution backbone for TTS, conversation, clone, and batch workflows.
- `projects/` and `script_assets/` let you move from single-run utility to studio-grade batch production.
- `usage_events` + `credit_ledger` are required from day one if you want clean billing and refunds.
