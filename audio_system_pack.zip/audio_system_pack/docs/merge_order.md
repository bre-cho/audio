# Audio AI System — Merge Order

## Merge 1 — Foundation
Add first:
- provider model + table
- voice model + table
- audio_job + audio_output + usage_event + credit_ledger
- storage abstraction
- base provider interface

Verify:
- migrations apply cleanly
- app boots
- no route breakage

## Merge 2 — Basic TTS
Add:
- `api/tts.py`
- `schemas/tts.py`
- `services/tts_service.py`
- first provider adapter
- worker task for TTS

Verify:
- one text request queues job
- worker writes output
- credit reserve + settlement works

## Merge 3 — Voice Library
Add:
- `api/voices.py`
- `voice_library_service.py`
- search/filter list UI

Verify:
- system voices list
- select voice from UI
- preview path works

## Merge 4 — Voice Clone
Add:
- `voice_samples`
- upload endpoint
- clone create endpoint
- clone worker
- moderation + consent check

Verify:
- upload passes validation
- clone job succeeds
- cloned voice appears in library

## Merge 5 — Conversation Engine
Add:
- parser util
- conversation endpoints
- `conversation_segments`
- merge worker

Verify:
- raw conversation script parses
- segments render in order
- final merged file is playable

## Merge 6 — Studio / Projects
Add:
- project CRUD
- script assets
- batch generate
- outputs list
- export bundle

Verify:
- one project holds many scripts
- batch queue spins up jobs
- export zip downloads

## Merge 7 — Ops Grade Hardening
Add:
- admin tools
- telemetry dashboards
- webhook reconciliation
- retry/cancel controls
- housekeeping tasks

Verify:
- failed job retry works
- stuck job cleanup works
- usage and cost data are queryable

## Hard Rules
- Do not import provider adapters in route handlers.
- Do not bypass `audio_jobs` for any generation path.
- Do not skip credit ledger entries for preview, success, fail, or refund.
- Do not merge conversation outputs inline in the request thread.
