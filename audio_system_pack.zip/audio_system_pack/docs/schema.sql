create extension if not exists pgcrypto;

create table users (
  id uuid primary key default gen_random_uuid(),
  email varchar(255) unique not null,
  password_hash varchar(255),
  full_name varchar(255),
  role varchar(50) not null default 'user',
  status varchar(50) not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table providers (
  id uuid primary key default gen_random_uuid(),
  code varchar(50) unique not null,
  name varchar(120) not null,
  status varchar(50) not null default 'active',
  is_default boolean not null default false,
  config_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table voices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid null references users(id) on delete cascade,
  provider_id uuid null references providers(id),
  external_voice_id varchar(255),
  source_type varchar(50) not null,
  visibility varchar(50) not null default 'private',
  name varchar(255) not null,
  language_code varchar(50),
  gender varchar(50),
  age_group varchar(50),
  tone_tags jsonb not null default '[]'::jsonb,
  style_tags jsonb not null default '[]'::jsonb,
  quality_tier varchar(50),
  preview_url text,
  avatar_url text,
  is_active boolean not null default true,
  moderation_status varchar(50) not null default 'approved',
  metadata_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table voice_samples (
  id uuid primary key default gen_random_uuid(),
  voice_id uuid null references voices(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  storage_key text not null,
  original_filename varchar(255),
  mime_type varchar(120),
  duration_ms integer,
  size_bytes bigint,
  sample_type varchar(50) not null default 'clone_source',
  consent_confirmed boolean not null default false,
  created_at timestamptz not null default now()
);

create table projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  title varchar(255) not null,
  description text,
  project_type varchar(50) not null default 'audio',
  status varchar(50) not null default 'draft',
  settings_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table script_assets (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  asset_type varchar(50) not null,
  title varchar(255),
  raw_text text,
  normalized_text text,
  language_code varchar(50),
  metadata_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table audio_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  project_id uuid null references projects(id) on delete set null,
  script_asset_id uuid null references script_assets(id) on delete set null,
  provider_id uuid null references providers(id),
  voice_id uuid null references voices(id),
  job_type varchar(50) not null,
  status varchar(50) not null default 'queued',
  priority integer not null default 100,
  request_json jsonb not null default '{}'::jsonb,
  runtime_json jsonb not null default '{}'::jsonb,
  estimated_credits integer not null default 0,
  reserved_credits integer not null default 0,
  settled_credits integer not null default 0,
  error_code varchar(120),
  error_message text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table conversation_segments (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references audio_jobs(id) on delete cascade,
  speaker_label varchar(120) not null,
  voice_id uuid null references voices(id),
  provider_id uuid null references providers(id),
  segment_order integer not null,
  segment_text text not null,
  segment_ssml text,
  status varchar(50) not null default 'queued',
  duration_ms integer,
  output_id uuid null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(job_id, segment_order)
);

create table audio_outputs (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references audio_jobs(id) on delete cascade,
  output_type varchar(50) not null,
  storage_key text not null,
  public_url text,
  mime_type varchar(120),
  duration_ms integer,
  size_bytes bigint,
  waveform_json jsonb,
  checksum varchar(128),
  created_at timestamptz not null default now()
);

create table credit_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  job_id uuid null references audio_jobs(id) on delete set null,
  delta_credits integer not null,
  event_type varchar(50) not null,
  balance_after integer,
  note text,
  metadata_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table usage_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid null references users(id) on delete set null,
  project_id uuid null references projects(id) on delete set null,
  job_id uuid null references audio_jobs(id) on delete set null,
  event_name varchar(120) not null,
  provider_code varchar(50),
  units bigint,
  unit_type varchar(50),
  estimated_cost numeric(18,6),
  actual_cost numeric(18,6),
  metadata_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table webhook_events (
  id uuid primary key default gen_random_uuid(),
  provider_code varchar(50) not null,
  external_event_id varchar(255),
  event_type varchar(120) not null,
  payload_json jsonb not null,
  processed boolean not null default false,
  processed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(provider_code, external_event_id, event_type)
);

create index idx_voices_user_id on voices(user_id);
create index idx_voices_source_type on voices(source_type);
create index idx_projects_user_id on projects(user_id);
create index idx_audio_jobs_user_id on audio_jobs(user_id);
create index idx_audio_jobs_project_id on audio_jobs(project_id);
create index idx_audio_jobs_status on audio_jobs(status);
create index idx_audio_jobs_job_type on audio_jobs(job_type);
create index idx_credit_ledger_user_id on credit_ledger(user_id);
create index idx_usage_events_user_id on usage_events(user_id);
