# Merge Order

1. Merge P0 files + env/config/router.
2. Run `pytest backend/tests/test_p0_runtime_truth.py`.
3. Merge P1 capability gate + router + frontend capability matrix.
4. Run `pytest backend/tests/test_p1_provider_capability_gate.py`.
5. Merge P2 provider files, set API keys only in secret manager.
6. Merge P3 STT; verify SRT/VTT exports.
7. Merge P4 podcast; verify sample mixdown.
8. Merge P5/P6 disabled by default; enable one provider at a time.
9. Merge P7 dashboard.
10. Run `bash scripts/verify_audio_production_v2.sh`.
