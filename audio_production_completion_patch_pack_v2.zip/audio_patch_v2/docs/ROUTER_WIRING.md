# Router Wiring

Trong `backend/app/api/router.py`, thêm imports:

```python
from app.api import runtime_truth, system_capabilities_v2, transcription_v2, podcast_v2, voice_changer_v2, sfx_bgm_v2, audio_quality_v2
```

Thêm include router:

```python
api_router.include_router(runtime_truth.router, prefix="/runtime-truth", tags=["runtime-truth"])
api_router.include_router(system_capabilities_v2.router, prefix="/system-capabilities-v2", tags=["system-capabilities"])
api_router.include_router(transcription_v2.router, prefix="/transcription-v2", tags=["transcription"])
api_router.include_router(podcast_v2.router, prefix="/podcast-v2", tags=["podcast"])
api_router.include_router(voice_changer_v2.router, prefix="/voice-changer-v2", tags=["voice-changer"])
api_router.include_router(sfx_bgm_v2.router, prefix="/sfx-bgm-v2", tags=["sfx-bgm"])
api_router.include_router(audio_quality_v2.router, prefix="/audio-quality-v2", tags=["audio-quality"])
```

Nếu project dùng `app.include_router(api_router, prefix="/api/v1")` thì endpoint cuối sẽ là `/api/v1/...`.
