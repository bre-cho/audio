# Patch Phases P0 → P7

## P0 — Runtime Truth Patch

Sửa mục tiêu: chặn mock/stub/placeholder trong staging/prod.

Files thêm:
- `backend/app/core/production_truth.py`
- `backend/app/services/audio_signal_validator.py`
- `backend/app/api/runtime_truth.py`
- `backend/tests/test_p0_runtime_truth.py`

Files cần chỉnh:
- `backend/app/core/config.py`: default `allow_placeholder_audio = False`
- `.env.example`: thêm biến truth gate
- `backend/app/api/router.py`: include runtime_truth router

Acceptance:
- Production + provider `internal_genvoice` → 409/blocked.
- Silent WAV output → fail artifact promotion.
- Missing API key với provider bắt buộc → blocked.

## P1 — Provider Capability Hard Gate

Sửa mục tiêu: route chỉ chạy nếu provider có capability thật.

Files thêm:
- `backend/app/services/provider_capability_gate_v2.py`
- `backend/app/api/system_capabilities_v2.py`
- `backend/tests/test_p1_provider_capability_gate.py`

Acceptance:
- `/api/v1/system-capabilities-v2` trả matrix capability.
- Module disabled trả lý do rõ.
- Frontend đọc capability để disable UI.

## P2 — ElevenLabs Real TTS + Clone

Sửa mục tiêu: provider ElevenLabs không còn queued giả.

Files thêm:
- `backend/app/providers/elevenlabs_real.py`
- `backend/app/services/real_tts_service.py`
- `backend/app/services/real_clone_service.py`
- `backend/tests/test_p2_elevenlabs_provider_contract.py`

Acceptance:
- Có timeout/retry/error mapping.
- Clone trả `external_voice_id` hoặc error thật.
- Không fallback silent WAV nếu provider lỗi.

## P3 — STT + Subtitle Engine

Files thêm:
- `backend/app/audio_engines/stt/whisper_adapter.py`
- `backend/app/services/subtitle_export_service_v2.py`
- `backend/app/api/transcription_v2.py`

Acceptance:
- Export `.json`, `.srt`, `.vtt`.
- Có segment timestamp, language, confidence.

## P4 — Podcast Mixdown Engine

Files thêm:
- `backend/app/audio_engines/podcast/mixdown_engine_v2.py`
- `backend/app/services/podcast_production_service.py`
- `backend/app/api/podcast_v2.py`

Acceptance:
- multi-speaker script → TTS segments → timeline → final WAV.
- BGM ducking, intro/outro optional, LUFS normalize.

## P5 — Voice Changer Adapter

Files thêm:
- `backend/app/audio_engines/voice_changer/conversion_adapter_v2.py`
- `backend/app/services/speaker_similarity_service.py`
- `backend/app/api/voice_changer_v2.py`

Acceptance:
- Local RVC/OpenVoice/provider modes.
- similarity/naturalness/artifact score.
- Disabled engine returns 409, not fake output.

## P6 — SFX + BGM Provider Patch

Files thêm:
- `backend/app/audio_engines/sound_effects/sfx_provider_adapter.py`
- `backend/app/audio_engines/bgm/bgm_provider_adapter.py`
- `backend/app/services/license_metadata_service.py`
- `backend/app/api/sfx_bgm_v2.py`

Acceptance:
- prompt-to-sfx / prompt-to-bgm contract.
- license metadata required.
- duration and signal validation.

## P7 — Audio QA Dashboard

Files thêm:
- `backend/app/audio_engines/qa/audio_quality_metrics.py`
- `backend/app/api/audio_quality_v2.py`
- `frontend/src/components/audio/CapabilityMatrix.tsx`
- `frontend/src/components/audio/AudioQADashboard.tsx`

Acceptance:
- QA returns LUFS/RMS/peak/clipping/silence ratio/SNR estimate.
- UI shows capability and artifact QA state.
