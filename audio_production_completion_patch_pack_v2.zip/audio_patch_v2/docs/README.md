# AUDIO PRODUCTION COMPLETION PATCH PACK V2

Mục tiêu: nâng repo `audio-main-2` từ scaffold AI Audio Studio thành production-grade Audio Platform theo chuẩn FineVoice-style: truthful runtime, provider capability gate, real TTS/Clone/STT, voice changer, SFX/BGM, podcast mixdown, audio QA dashboard.

## Nguyên tắc áp dụng

- Additive-first: ưu tiên thêm file mới, chỉ sửa router/config/env khi cần wire.
- No fake production: không fallback silent WAV, không queued giả với engine chưa có provider thật.
- Capability-driven UI/API: mọi tính năng phải báo `ready | partial | disabled | blocked | planned`.
- Artifact contract là nguồn sự thật: mọi output phải có checksum, signal validation, provider metadata, promotion status.

## Phase order

1. P0 Runtime Truth Patch
2. P1 Provider Capability Hard Gate
3. P2 ElevenLabs Real TTS + Clone Patch
4. P3 STT + Subtitle Engine Patch
5. P4 Podcast Mixdown Engine Patch
6. P5 Voice Changer RVC/OpenVoice Adapter Patch
7. P6 SFX + BGM Provider Patch
8. P7 Audio QA Dashboard Patch

## Cách apply nhanh

```bash
# từ root repo audio-main
cp -R patch_pack/backend/* backend/
cp -R patch_pack/frontend/* frontend/
cp -R patch_pack/scripts/* scripts/
cp -R patch_pack/smoke_payloads ./.smoke_payloads

# wire router theo docs/ROUTER_WIRING.md
# cập nhật env theo docs/ENV_PATCH.md

cd backend
alembic upgrade head
pytest -q

cd ..
bash scripts/verify_audio_production_v2.sh
```

## Kết quả mong đợi

- Production không còn placeholder/silent output.
- API trả lỗi rõ khi provider chưa sẵn sàng.
- TTS/clone/STT có adapter thật hoặc blocked minh bạch.
- Podcast có timeline + mixdown + loudness normalization.
- Voice changer có adapter layer, similarity/artifact QA.
- SFX/BGM có provider contract và license metadata.
- Frontend sync capability, disable nút chưa ready.
