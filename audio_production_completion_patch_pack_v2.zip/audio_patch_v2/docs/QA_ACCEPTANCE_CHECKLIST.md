# QA Acceptance Checklist

## Runtime
- [ ] `ALLOW_PLACEHOLDER_AUDIO=false` in production.
- [ ] internal/mock/stub providers blocked in production.
- [ ] disabled engines return 409 with reason.

## Audio Artifact
- [ ] size > 0
- [ ] checksum exists
- [ ] duration > 0
- [ ] RMS above threshold
- [ ] silence ratio below threshold
- [ ] provider metadata attached
- [ ] generation_mode != placeholder in production

## Provider
- [ ] timeout configured
- [ ] retry bounded
- [ ] error mapping preserved
- [ ] no silent fallback

## Feature
- [ ] TTS real provider tested
- [ ] Clone returns provider voice id
- [ ] STT exports JSON/SRT/VTT
- [ ] Podcast mixdown creates final artifact
- [ ] Voice changer disabled if no real engine
- [ ] SFX/BGM disabled if no provider
