# Patch Order

## Phase 1 — Add finalizer

```txt
1. Add backend/app/audio_factory/job_finalizer.py
2. Export AudioJobFinalizer in backend/app/audio_factory/__init__.py
```

## Phase 2 — Refactor audio workers

```txt
1. Replace _success_runtime with AudioJobFinalizer.build_runtime_json()
2. Replace _mark_job_succeeded_with_artifacts with AudioJobFinalizer.finalize_success()
3. Return runtime_json from worker so API/test response remains compatible
```

## Phase 3 — Refactor clone preview worker

```txt
1. Replace _clone_preview_runtime with AudioJobFinalizer.build_runtime_json()
2. Replace _mark_clone_preview_succeeded_with_artifacts with AudioJobFinalizer.finalize_success()
3. Keep process_clone_job unchanged because it creates a voice profile, not an audio artifact
```

## Phase 4 — Regression tests

```txt
1. Finalizer rejects success with empty artifacts
2. Finalizer rejects success if factory claims DB pass but audio_outputs row is missing
3. Existing worker artifact guard proves success path still works
```

## Phase 5 — CI verify

```bash
python -m compileall backend/app/audio_factory backend/app/workers backend/tests
cd backend
PYTHONPATH=. pytest -q tests/test_audio_job_finalizer.py tests/test_audio_worker_artifact_guard.py
```
