# Verify Checklist

```txt
[ ] AudioJobFinalizer exists.
[ ] AudioJobFinalizer exported from app.audio_factory.
[ ] audio_tasks.py no longer defines _success_runtime.
[ ] audio_tasks.py no longer defines _mark_job_succeeded_with_artifacts.
[ ] clone_tasks.py no longer defines _clone_preview_runtime.
[ ] clone_tasks.py no longer defines _mark_clone_preview_succeeded_with_artifacts.
[ ] Worker result still returns artifacts, preview_url, output_url.
[ ] runtime_json contains workflow_type.
[ ] runtime_json contains factory_validation.file.passed = true.
[ ] runtime_json contains factory_validation.db.passed = true.
[ ] runtime_json.promotion_gate.db_persistence_pass = true.
[ ] Missing audio_outputs row blocks succeeded.
[ ] Empty artifacts blocks succeeded.
```
