# FINAL SUCCESS CONTRACT PATCH

## Mục tiêu

Gom toàn bộ đường `mark succeeded` của audio worker về một cổng duy nhất:

```txt
AudioFactoryResult
→ AudioJobFinalizer.assert_success_contract()
→ validate factory file result
→ validate factory DB result
→ validate audio_outputs rows
→ write runtime_json
→ set job.status = succeeded
```

## Luật khóa

```txt
NO FACTORY SUCCESS → NO JOB SUCCESS
NO ARTIFACTS → NO JOB SUCCESS
NO FILE VALIDATION PASS → NO JOB SUCCESS
NO DB VALIDATION PASS → NO JOB SUCCESS
NO audio_outputs ROW → NO JOB SUCCESS
NO PERSISTED/VERIFIED PROMOTION STATUS → NO JOB SUCCESS
```

## Files thay đổi

```txt
backend/app/audio_factory/job_finalizer.py         # new
backend/app/audio_factory/__init__.py              # export finalizer
backend/app/workers/audio_tasks.py                 # remove local success runtime builders
backend/app/workers/clone_tasks.py                 # remove clone preview local success builder
backend/tests/test_audio_job_finalizer.py          # new regression tests
```

## Cách apply

```bash
git apply FINAL_SUCCESS_CONTRACT_PATCH.diff
```

Hoặc copy từ:

```txt
changed_files/
```

vào repo.

## Verify

```bash
python -m compileall backend/app/audio_factory backend/app/workers backend/tests
cd backend
PYTHONPATH=. pytest -q tests/test_audio_job_finalizer.py tests/test_audio_worker_artifact_guard.py
```

## Kỳ vọng sau patch

`_success_runtime`, `_clone_preview_runtime`, `_mark_job_succeeded_with_artifacts`, `_mark_clone_preview_succeeded_with_artifacts` không còn là cổng success riêng. Worker chỉ được gọi:

```python
AudioJobFinalizer().finalize_success(...)
```

Điều này đảm bảo một job chỉ `succeeded` khi factory validation và DB persistence đã pass thật.
