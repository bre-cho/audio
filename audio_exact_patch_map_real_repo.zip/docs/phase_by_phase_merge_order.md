
# Phase-by-phase merge order against the observed repo

## Phase 1 — Data-safe extensions
1. extend `backend/app/models/voice_profile.py`
2. extend `backend/app/models/voice_sample.py`
3. add new models:
   - `audio_job.py`
   - `audio_output.py`
   - `conversation_segment.py`
4. add migration from these model changes

## Phase 2 — API-safe bridge
1. extend `backend/app/api/audio.py`
2. add schemas for:
   - TTS request/response
   - conversation request/response
   - clone request/response
3. keep routes under existing audio namespace first

## Phase 3 — Worker-safe bridge
1. extend `backend/app/workers/voice_clone_worker.py`
2. add service files under `backend/app/services/audio/`
3. add provider adapters under `backend/app/providers/audio/`

## Phase 4 — Render integration
1. extend `backend/app/api/render_execution.py`
2. keep all new fields optional
3. only trigger audio generation when payload explicitly asks for it

## Phase 5 — Project/history integration
1. optional bridge into `project_workspace.py`
2. optional bridge into `render_job_status.py`
3. surface linked audio outputs in project detail/status pages
