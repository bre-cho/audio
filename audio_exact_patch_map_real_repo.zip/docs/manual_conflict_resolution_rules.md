
# Manual conflict resolution rules

## Rule 1
If `backend/app/api/audio.py` already contains routers or helper functions:
- do not replace the file
- append a dedicated section:
  - `# === Audio AI System patch start ===`
  - `# === Audio AI System patch end ===`

## Rule 2
If `voice_profile.py` already has provider metadata:
- merge fields semantically
- prefer existing naming if meaning is the same
- avoid duplicate concepts like both `provider_voice_id` and `external_voice_id` unless they truly differ

## Rule 3
If `voice_clone_worker.py` uses a different queue framework:
- port task names only
- do not force Celery if the repo already standardized on another async runtime

## Rule 4
In `render_execution.py`:
- every new request field must stay optional
- do not change existing required render fields
- do not trigger audio generation by default

## Rule 5
If repo imports models through a registry file:
- add imports there instead of assuming auto-discovery
