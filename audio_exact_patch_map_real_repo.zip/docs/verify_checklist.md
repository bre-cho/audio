
# Verify checklist

## After model merge
- metadata imports succeed
- migration autogenerate sees new tables/columns
- no duplicate table names
- no import cycle from `models` -> `services`

## After API merge
- `/api/.../audio` routes still load
- old audio endpoints still work
- new TTS route returns 200/202 on mock request
- new conversation route returns 200/202 on mock request

## After worker merge
- worker still boots
- clone task still registers
- new TTS / conversation / merge tasks register

## After render bridge
- old render payload still validates unchanged
- render with new audio fields remains optional
- render request without audio does not enqueue audio work
