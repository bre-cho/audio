
# New files to add under the observed repo tree

backend/app/models/audio_job.py
backend/app/models/audio_output.py
backend/app/models/conversation_segment.py

backend/app/schemas/audio_generation.py
backend/app/schemas/conversation_generation.py

backend/app/services/audio/tts_service.py
backend/app/services/audio/conversation_service.py
backend/app/services/audio/audio_merge_service.py
backend/app/services/audio/provider_router.py

backend/app/providers/audio/base.py
backend/app/providers/audio/elevenlabs.py
backend/app/providers/audio/minimax.py
