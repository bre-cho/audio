
# Existing repo file matrix

| Existing file | Action | Why | Patch style |
|---|---|---|---|
| `backend/app/api/audio.py` | Extend | Natural public API entrypoint for audio features | append routes + request/response wiring |
| `backend/app/api/render_execution.py` | Extend | Needed to let render pipeline consume audio outputs | guarded field add + optional orchestration call |
| `backend/app/workers/voice_clone_worker.py` | Extend | Closest existing async audio worker | append tasks only |
| `backend/app/models/voice_profile.py` | Extend | Best place to attach provider voice metadata | add nullable columns only |
| `backend/app/models/voice_sample.py` | Extend | Needed for clone provenance/sample tracking | add metadata columns only |
| `backend/app/models/template_factory.py` | No change first | unrelated to audio MVP | do not touch |
| `backend/app/providers/veo/adapter.py` | No change first | video provider adapter should remain isolated | do not touch |
| `backend/app/services/provider_adapters/veo_adapter.py` | No change first | same reason | do not touch |
| `backend/app/api/project_workspace.py` | Optional later | can surface audio assets per project later | postpone |
| `backend/app/api/render_job_status.py` | Optional later | can expose linked audio job status later | postpone |
