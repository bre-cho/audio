
# Exact patch map against observed real repo tree

## Repo shape inferred from your existing codebase

The existing repo appears to center on a render-factory style FastAPI monorepo with these anchor files already present:

### Existing backend API anchors
- `backend/app/api/script_upload_preview.py`
- `backend/app/api/script_validation.py`
- `backend/app/api/project_workspace.py`
- `backend/app/api/render_execution.py`
- `backend/app/api/render_job_status.py`
- `backend/app/api/audio.py`
- `backend/app/api/templates.py`
- `backend/app/api/template_runtime.py`

### Existing provider/service anchors
- `backend/app/providers/veo/adapter.py`
- `backend/app/services/provider_adapters/veo_adapter.py`

### Existing worker/model anchors
- `backend/app/workers/voice_clone_worker.py`
- `backend/app/models/voice_profile.py`
- `backend/app/models/voice_sample.py`
- `backend/app/models/template_factory.py`

## Exact merge strategy

Instead of creating a parallel “audio app”, the safest merge is:

1. **Bridge into existing `audio.py`**
   - mount TTS / conversation / voice clone APIs here first
   - do not create a second public audio surface unless needed for versioning

2. **Bridge into existing `render_execution.py`**
   - allow render jobs to accept audio-related context:
     - `voice_id`
     - `audio_script_id`
     - `narration_mode`
     - `conversation_mode`
     - `provider_audio_strategy`
   - audio generation should be usable before or during render preparation

3. **Reuse existing worker conventions**
   - if `voice_clone_worker.py` already exists, add new task handlers beside it rather than inventing a second clone pipeline
   - add:
     - `tts_generate`
     - `conversation_generate`
     - `audio_merge`

4. **Reuse existing voice models**
   - extend `voice_profile.py` first
   - only create new models where the current voice models cannot hold the concept cleanly

## Create / extend matrix

### Extend existing files first
- `backend/app/api/audio.py`
- `backend/app/api/render_execution.py`
- `backend/app/workers/voice_clone_worker.py`
- `backend/app/models/voice_profile.py`
- `backend/app/models/voice_sample.py`

### Create new files second
- `backend/app/models/audio_job.py`
- `backend/app/models/audio_output.py`
- `backend/app/models/conversation_segment.py`
- `backend/app/schemas/audio_generation.py`
- `backend/app/schemas/conversation_generation.py`
- `backend/app/services/audio/tts_service.py`
- `backend/app/services/audio/conversation_service.py`
- `backend/app/services/audio/audio_merge_service.py`
- `backend/app/services/audio/provider_router.py`
- `backend/app/providers/audio/base.py`
- `backend/app/providers/audio/elevenlabs.py`
- `backend/app/providers/audio/minimax.py`

## Files that should stay untouched in the first merge wave
- `backend/app/api/project_workspace.py`
- `backend/app/api/template_runtime.py`
- `backend/app/providers/veo/adapter.py`
- `backend/app/services/provider_adapters/veo_adapter.py`

Reason:
These are execution-core and template-core files. Audio should plug into them later through orchestration, not rewrite them on day one.
