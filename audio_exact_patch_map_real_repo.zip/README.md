# BUILD EXACT PATCH MAP AGAINST REAL REPO TREE

This pack maps the audio AI system into the user's *observed* repo tree from file-library evidence.

Important honesty note:
- This is **exact against the observed repo paths and module patterns**, not a live filesystem scan of the current repo checkout.
- It is based on repo/file evidence that references paths such as:
  - `backend/app/api/render_execution.py`
  - `backend/app/api/project_workspace.py`
  - `backend/app/api/audio.py`
  - `backend/app/api/templates.py`
  - `backend/app/providers/veo/adapter.py`
  - `backend/app/services/provider_adapters/veo_adapter.py`
  - `backend/app/workers/voice_clone_worker.py`
  - `backend/app/models/voice_profile.py`
  - `backend/app/models/voice_sample.py`

Use this pack when you want a merge plan that fits the real repo shape already described in prior files.
