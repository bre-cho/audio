#!/usr/bin/env bash
set -euo pipefail

echo "== exact repo checks =="
for f in   backend/app/api/audio.py   backend/app/api/render_execution.py   backend/app/workers/voice_clone_worker.py   backend/app/models/voice_profile.py   backend/app/models/voice_sample.py
do
  if [ -f "$f" ]; then
    echo "[FOUND] $f"
  else
    echo "[MISSING] $f"
  fi
done

echo
echo "== grep anchors =="
grep -R "render_execution\|voice_clone\|audio" backend/app/api backend/app/workers backend/app/models 2>/dev/null | head -n 200 || true
