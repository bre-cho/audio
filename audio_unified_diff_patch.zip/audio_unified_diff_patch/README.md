# Audio Backend Unified Diff Patch

Bộ này xuất từ skeleton backend đã dựng trước đó, ở dạng **unified diff patch by file** để dev có thể:
- áp toàn bộ bằng 1 file: `audio_backend_full.patch`
- hoặc áp từng file riêng trong thư mục `patches/`

## Cấu trúc
- `audio_backend_full.patch`: patch gộp toàn bộ file
- `patches/...`: 1 file `.patch` cho mỗi file nguồn
- `apply_patch_examples.sh`: ví dụ lệnh áp patch
- `patch_manifest.txt`: danh sách file patch

## Cách dùng nhanh
Áp toàn bộ tại root repo:
```bash
git apply /path/to/audio_backend_full.patch
```

Áp từng file:
```bash
git apply /path/to/patches/backend/app/main.py.patch
git apply /path/to/patches/backend/app/api/router.py.patch
```

## Lưu ý
- Đây là patch **additive**: giả định các file đích chưa tồn tại.
- Nếu repo của bạn đã có sẵn file trùng tên, hãy dùng các file trong `patches/` như tài liệu merge thủ công hoặc chỉnh lại diff theo file cũ.
- Nếu repo đang dùng layout khác (`src/app/...`, `backend/src/...`), cần đổi prefix đường dẫn trước khi apply.

## Thống kê
- Tổng số patch file: 65
