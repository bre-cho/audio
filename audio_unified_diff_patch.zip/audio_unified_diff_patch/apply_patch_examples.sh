#!/usr/bin/env bash
set -euo pipefail

PATCH_ROOT="${1:-.}"

echo "[1/2] Applying consolidated patch..."
git apply "${PATCH_ROOT}/audio_backend_full.patch"

echo "[2/2] Done."
