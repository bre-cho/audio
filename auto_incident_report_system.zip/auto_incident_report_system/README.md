# AUTO INCIDENT REPORT SYSTEM

This pack creates an automated SRE-style incident report lane.

Included:
- `.github/workflows/auto-incident-report.yml`
- `scripts/incident/collect_root_cause_snapshot.sh`
- `scripts/incident/generate_incident_report.sh`
- `scripts/incident/build_incident_slack_payload.py`
- `templates/INCIDENT_REPORT_TEMPLATE.md`

What it does:
1. Collects compose state, service logs, health endpoints, metrics, Alertmanager alerts, and Prometheus query snapshots.
2. Generates `.incident_report/INCIDENT_REPORT.md`.
3. Uploads artifacts and posts a Slack summary.
