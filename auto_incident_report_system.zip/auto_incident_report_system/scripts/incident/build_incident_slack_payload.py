#!/usr/bin/env python3
import json
from pathlib import Path

report_dir = Path(".incident_report")
report_path = report_dir / "INCIDENT_REPORT.md"

summary = "Incident report generated"
if report_path.exists():
    text = report_path.read_text(encoding="utf-8", errors="ignore")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip().startswith("- ")]
    summary = "\n".join(lines[:6]) if lines else summary

payload = {
    "text": "[AUTO-INCIDENT-REPORT] Report ready",
    "blocks": [
        {"type": "header", "text": {"type": "plain_text", "text": "AUTO INCIDENT REPORT"}},
        {"type": "section", "text": {"type": "mrkdwn", "text": summary[:2800]}},
        {"type": "section", "text": {"type": "mrkdwn", "text": "Artifact: `auto-incident-report` from the workflow run."}},
    ]
}
print(json.dumps(payload))
