# FULL PROVIDER ROUTER AUDIO PATCH

Pack này cắm **audio multi-provider routing** vào repo hiện tại mà không đập render provider core.

## Mục tiêu
- giữ nguyên `backend/app/services/provider_router.py` cho video render
- thêm router song song cho audio: TTS / voice clone / preview / music
- thay hardcode `ElevenLabsAdapter()` trong audio layer bằng `get_audio_provider_adapter(...)`
- cho phép mở rộng provider mới như `minimax` mà không sửa lại service business

## File mới
- `backend/app/services/audio/provider_base.py`
- `backend/app/services/audio/providers/elevenlabs_provider.py`
- `backend/app/services/audio/providers/minimax_provider.py`
- `backend/app/services/audio_provider_router.py`

## File sửa
- `backend/app/core/config.py`
- `backend/app/schemas/audio.py`
- `backend/app/api/audio.py`
- `backend/app/services/audio/voice_clone_service.py`
- `backend/app/services/audio/narration_service.py`

## Merge order
1. Add new provider files
2. Patch config + schemas
3. Patch `voice_clone_service.py`
4. Patch `narration_service.py`
5. Patch `api/audio.py`
6. Smoke test preview / clone / narration with provider=`elevenlabs`

## Ghi chú
`minimax_provider.py` trong pack này là skeleton có TODO ở HTTP mapping. Ý tưởng là cắm interface trước, sau đó map API thật sau.
