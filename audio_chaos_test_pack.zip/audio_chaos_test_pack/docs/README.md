# Audio Chaos Test Pack

This pack contains a repo-ready chaos script for the audio pipeline.

## Included scenarios
- worker_kill
- provider_fail
- ffmpeg_delay
- queue_backlog

## Basic run
```bash
bash scripts/chaos/audio_chaos_test.sh
```

## Typical staging run
```bash
BASE_URL=http://localhost:8000 \
ALERTMANAGER_URL=http://localhost:9093 \
API_SERVICE=api \
WORKER_SERVICE=worker \
REDIS_SERVICE=redis \
DOCKER_COMPOSE_BIN="docker compose" \
SCENARIOS=worker_kill,provider_fail,ffmpeg_delay,queue_backlog \
bash scripts/chaos/audio_chaos_test.sh
```

## With auth and sample
```bash
AUTH_ENABLED=1 \
AUTH_EMAIL=test@example.com \
AUTH_PASSWORD=secret \
SAMPLE_PATH=./sample.mp3 \
bash scripts/chaos/audio_chaos_test.sh
```

## Output
- `.audio_chaos_report/report.txt`
- `.audio_chaos_report/run.log`
