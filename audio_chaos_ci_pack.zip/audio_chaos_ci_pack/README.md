# Audio Chaos CI Pack

This pack adds a scheduled GitHub Actions workflow that runs the staging chaos test for the audio pipeline and fails if the expected Alertmanager alerts do not appear.

## Files
- `.github/workflows/audio-chaos-ci.yml`
- `docs/AUDIO_CHAOS_CI_PATCH.md`

## Required repo files
- `scripts/chaos/audio_chaos_test.sh`

## Required secrets
- `STAGING_BASE_URL`
- `STAGING_ALERTMANAGER_URL`
- `SLACK_WEBHOOK_URL`
- `TEST_USER_EMAIL` / `TEST_USER_PASSWORD` if auth is enabled
- Optional: `AUDIO_TEST_AUTH_ENABLED`, `CHAOS_SAMPLE_PATH`

## What it does
1. Checks out the repo.
2. Runs `scripts/chaos/audio_chaos_test.sh` against staging.
3. Queries Alertmanager `/api/v2/alerts`.
4. Verifies the expected alert names appeared for the chosen scenarios.
5. Uploads artifacts and sends Slack if the verification failed.
