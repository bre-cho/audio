# Audio Deploy Guard + Auto Rollback Pack

This pack adds a deployment gate for the audio pipeline and an automatic rollback path when post-deploy audio verification fails.

## Included
- `.github/workflows/audio-deploy-guard.yml`
- `scripts/deploy/deploy_guard.sh`
- `scripts/deploy/auto_rollback.sh`
- `scripts/deploy/post_deploy_audio_smoke.sh`
- `docs/AUDIO_DEPLOY_GUARD_PATCH.md`
- `docs/SECRETS_AND_ENV.md`
- `docs/ROLLBACK_STRATEGY.md`

## Goal
- Block production deploy unless audio CI / audio E2E is green
- Run post-deploy audio smoke checks
- Auto rollback if audio smoke fails after deploy
- Send Slack alerts on block / rollback

## Main assumptions
- Deployment target is controlled by shell scripts or a release job
- The repo already has `verify_audio_e2e.sh`
- Current and previous revisions are available in the deployment environment
