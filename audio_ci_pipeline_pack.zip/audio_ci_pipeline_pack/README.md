# Audio CI Pipeline Pack

Pack này thêm 1 pipeline CI riêng cho audio vào repo hiện tại, gồm:
- workflow GitHub Actions cho compile + smoke + audio E2E
- fail-safe thu log/artifact khi lỗi
- Slack alert khi pipeline fail hoặc hồi phục
- script verify cục bộ để dev chạy giống CI

## Files
- `.github/workflows/audio-ci-e2e.yml`
- `scripts/ci/verify_audio_patch.sh`
- `scripts/ci/verify_audio_e2e.sh`
- `scripts/ci/audio_fail_safe.sh`
- `scripts/ci/build_audio_slack_payload.py`
- `docs/AUDIO_CI_PIPELINE_PATCH.md`

## Secrets cần tạo
- `SLACK_WEBHOOK_URL`
- nếu endpoint audio cần auth: `AUDIO_E2E_EMAIL`, `AUDIO_E2E_PASSWORD`

## Env repo nên có
- docker compose services: `api`, `worker`
- app health endpoint: `http://localhost:8000/healthz`
- ffmpeg trong container `api`

## Tích hợp nhanh
Copy các file vào repo rồi commit. Workflow sẽ chỉ chạy khi phần audio/CI liên quan thay đổi hoặc khi trigger tay.
