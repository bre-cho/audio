# Real-Time Audio Health Monitor + Alert Rules Pack

Repo-ready pack để bổ sung observability production-grade cho audio pipeline hiện có.

## Thành phần
- Prometheus scrape config cho API + node-exporter + cAdvisor + blackbox exporter
- Alert rules riêng cho audio pipeline
- Alertmanager config với route tách biệt cho audio
- Grafana dashboard JSON cho audio health
- Script smoke/check hỗ trợ heartbeat và synthetic probe
- GitHub Actions workflow chạy synthetic audio monitor theo lịch
- Runbook xử lý incident audio

## Mục tiêu
Theo dõi 4 lớp:
1. API /metrics và /health
2. Worker queue / Celery health
3. Audio functional health: preview + narration synthetic probe
4. Kết quả business-level: failure rate, stuck jobs, clone backlog, preview latency

## Cắm vào repo hiện tại
- Giữ nguyên `backend/app/services/observability_metrics.py`
- Thêm audio metrics exporter/endpoint ở backend
- Mount thư mục `infra/monitoring/*` vào Prometheus/Grafana/Alertmanager hiện có
- Dùng workflow `.github/workflows/audio-health-monitor.yml` làm synthetic canary ngoài deploy lane
