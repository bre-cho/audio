from __future__ import annotations

import json
import os
from pathlib import Path

report = Path(os.getenv('REPORT_FILE', '.audio_synthetic_probe/status.txt'))
status = report.read_text(encoding='utf-8').strip() if report.exists() else 'unknown'
run_url = os.getenv('GITHUB_RUN_URL', '')
base_url = os.getenv('BASE_URL', '')

payload = {
    'text': f'Audio synthetic monitor: {status}',
    'blocks': [
        {'type': 'section', 'text': {'type': 'mrkdwn', 'text': f'*Audio synthetic monitor*
Status: `{status}`
Base URL: `{base_url}`'}},
        {'type': 'section', 'text': {'type': 'mrkdwn', 'text': f'Run: {run_url or "n/a"}'}}
    ]
}
print(json.dumps(payload))
