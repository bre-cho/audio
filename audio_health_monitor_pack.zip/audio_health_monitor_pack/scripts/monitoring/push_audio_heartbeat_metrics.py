from __future__ import annotations

import argparse
import time
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--preview-ok', action='store_true')
    parser.add_argument('--narration-ok', action='store_true')
    args = parser.parse_args()

    now = int(time.time())
    lines = []
    if args.preview_ok:
        lines.append(f'audio_preview_last_success_timestamp_seconds {now}')
    if args.narration_ok:
        lines.append(f'audio_narration_last_success_timestamp_seconds {now}')

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('
'.join(lines) + ('
' if lines else ''), encoding='utf-8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
