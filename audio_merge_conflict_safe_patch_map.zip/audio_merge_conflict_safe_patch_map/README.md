# Audio Backend — Merge-Conflict Safe Patch Map

Bộ này dùng khi repo đích **đã có sẵn file/code** và bạn muốn cấy Audio AI System vào mà giảm rủi ro đè code cũ.

## Mục tiêu
- Không giả định repo trống.
- Ưu tiên append / guarded wiring.
- Tách rõ file nào được tạo mới, file nào chỉ thêm import/router, file nào bắt buộc merge tay.
- Giữ execution core cũ hoạt động trong khi cấy audio module mới.

## Thành phần
- `docs/merge_conflict_safe_patch_map.md`: bản đồ merge chính theo từng file hiện hữu.
- `docs/existing_repo_file_matrix.md`: ma trận mức rủi ro, hành động, pre-check.
- `docs/phase_by_phase_merge_order.md`: thứ tự merge ít rủi ro nhất.
- `docs/manual_conflict_resolution_rules.md`: quy tắc xử lý conflict.
- `docs/verify_checklist.md`: lệnh verify nhanh sau từng phase.
- `scripts/repo_scan_commands.sh`: lệnh quét repo hiện tại trước khi patch.
- `patch_blocks/...`: các block chèn tối thiểu theo file/nhóm file.

## Cách dùng
1. Chạy `scripts/repo_scan_commands.sh` trong repo thật để biết file nào đã tồn tại.
2. Đối chiếu với `existing_repo_file_matrix.md`.
3. Merge theo đúng `phase_by_phase_merge_order.md`.
4. Chỉ dùng block trong `patch_blocks/` để chèn vào file hiện có; không copy đè nguyên file nếu repo đã có logic riêng.
5. Sau mỗi phase chạy `verify_checklist.md`.
