#!/usr/bin/env bash
set -euo pipefail

echo "== scan entrypoints =="
find backend -maxdepth 4 \( -name 'main.py' -o -name 'router.py' -o -name 'deps.py' \) | sort || true

echo "== scan app factory =="
grep -R "create_app\|FastAPI(" backend/app -n || true

echo "== scan router wiring =="
grep -R "include_router" backend/app -n || true

echo "== scan db base/session =="
grep -R "declarative_base\|SessionLocal\|sessionmaker\|get_db" backend/app -n || true

echo "== scan celery =="
grep -R "Celery(" backend/app -n || true

echo "== scan alembic =="
ls -la alembic || true
find alembic -maxdepth 2 -type f | sort || true

echo "== scan existing audio-like files =="
find backend/app \( -iname '*voice*' -o -iname '*audio*' -o -iname '*tts*' -o -iname '*provider*' \) | sort || true
