# Append-only example for existing app factory
from app.api.router import api_router as audio_api_router

# audio-ai patch start
app.include_router(audio_api_router, prefix='/api/v1')
# audio-ai patch end
