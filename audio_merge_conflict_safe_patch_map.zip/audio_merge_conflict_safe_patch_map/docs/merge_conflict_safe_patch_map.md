# Merge-Conflict Safe Patch Map By Existing Repo File

## 1. `backend/app/main.py`
### Chỉ sửa khi
- repo chưa có `/healthz`, hoặc
- app chưa include audio router.

### Không được làm
- không thay app factory cũ.
- không đổi middleware order.
- không đổi startup/lifespan cũ.

### Patch tối thiểu
1. thêm import audio router.
2. thêm `app.include_router(audio_api_router, prefix="/api/v1")` vào **cuối** vùng router wiring.
3. chỉ thêm health route nếu chưa có route tương tự.

---

## 2. Router gốc (`backend/app/api/router.py` hoặc file tương đương)
### Mục tiêu
Đăng ký các subrouter audio mà không đụng route cũ.

### Patch tối thiểu
- thêm import:
  - `billing`
  - `conversation`
  - `jobs`
  - `projects`
  - `providers`
  - `tts`
  - `voice_clone`
  - `voices`
- append `include_router(...)` cho audio ở cuối file.

### Nếu repo không có router aggregator chung
Tạo file mới `backend/app/api/audio_router.py`, rồi include file đó từ entrypoint hiện có.

---

## 3. `backend/app/api/deps.py`
### Mục tiêu
Nối audio services vào DI hiện có.

### Patch tối thiểu
- reuse session dependency cũ.
- thêm dependency factory cho:
  - `TTSService`
  - `ConversationService`
  - `VoiceCloneService`
  - `ProjectService`
  - `BillingService`

### Không được làm
- không tạo DB session thứ hai.
- không bypass auth/user context cũ.

---

## 4. `backend/app/core/config.py`
### Mục tiêu
Bổ sung env vars cho audio.

### Env vars nên thêm
- `AUDIO_DEFAULT_PROVIDER`
- `ELEVENLABS_API_KEY`
- `MINIMAX_API_KEY`
- `AUDIO_STORAGE_BUCKET`
- `AUDIO_PREVIEW_EXPIRE_SECONDS`
- `AUDIO_MAX_INPUT_CHARS`
- `AUDIO_MAX_UPLOAD_MB`
- `AUDIO_ENABLE_CLONE`

### Strategy an toàn
Nếu repo đã có `Settings/BaseSettings`, chỉ thêm field mới; không thay constructor hoặc source order.

---

## 5. `backend/app/core/storage.py`
### Mục tiêu
Dùng storage abstraction cũ để save audio outputs.

### Nếu đã có storage service
- thêm method kiểu:
  - `put_audio_bytes(...)`
  - `get_signed_audio_url(...)`
- hoặc map audio sang method object storage chung.

### Nếu chưa có
Dùng file skeleton storage nhưng giữ interface mỏng.

---

## 6. `backend/app/db/base.py`
### Mục tiêu
Đảm bảo Base/metadata thấy audio models.

### Patch tối thiểu
append import model audio vào registry import.

### Không được làm
- không tạo `Base = declarative_base()` lần hai.

---

## 7. `backend/app/db/session.py`
### Mục tiêu
Reuse session hiện có.

### Rule
- nếu repo đã có `SessionLocal/get_db`, không chèn file skeleton này.
- chỉ chỉnh import ở audio repos/services để dùng session hiện có.

---

## 8. `backend/app/models/*`
### Action
Tạo mới các model audio sau:
- `provider.py`
- `voice.py`
- `project.py`
- `script_asset.py`
- `audio_job.py`
- `audio_output.py`
- `credit_ledger.py`

### Nếu repo có naming convention khác
Đổi tên class/table cho khớp convention, nhưng giữ foreign key chain.

---

## 9. `backend/app/models/__init__.py`
Append export/import audio models để Alembic/autoload nhìn thấy.

---

## 10. `backend/app/schemas/*`
Tạo mới schema audio. Không merge vào schema domain cũ trừ khi repo đang dùng single-file schema style.

---

## 11. `backend/app/repositories/*`
Tạo mới repo audio. Nếu repo hiện có không dùng repository layer, fold logic vào service nhưng giữ transaction boundaries rõ ràng.

---

## 12. `backend/app/services/*`
Tạo mới:
- `tts_service.py`
- `conversation_service.py`
- `voice_clone_service.py`
- `project_service.py`
- `job_service.py`
- `billing_service.py`
- `provider_router.py`

### Rule
Service audio chỉ gọi qua provider router; không call provider adapter trực tiếp từ route.

---

## 13. `backend/app/providers/*`
Tạo mới adapter files. Không hardcode business logic vào adapter; chỉ normalize request/response/error.

---

## 14. `backend/app/workers/celery_app.py`
### Nếu repo đã có Celery app
- không tạo Celery instance mới.
- chỉ import/register task modules audio.

### Nếu repo chưa có
Dùng skeleton file.

---

## 15. `backend/app/workers/*.py`
Tạo mới task modules audio. Queue name phải theo convention cũ nếu repo đã dùng queue prefix.

---

## 16. `alembic/env.py`
### Patch tối thiểu
- đảm bảo target metadata đọc được Base chứa audio models.
- tránh sửa runtime path nếu repo đang chạy ổn.

---

## 17. `alembic/versions/*`
Sau khi model import registry ổn mới generate migration. Không viết migration trước khi topology sạch.

---

## 18. Test files
Tạo test mới thay vì sửa test cũ:
- `tests/api/test_tts_smoke.py`
- `tests/api/test_conversation_smoke.py`
- `tests/api/test_voice_clone_smoke.py`
- `tests/services/test_provider_router.py`
