# Existing Repo File Matrix

| Target file/pattern | Action | Risk | Why | Pre-check | Recommended strategy |
|---|---|---:|---|---|---|
| `backend/app/main.py` | guarded replace (small block) | High | thường đã có app factory, middleware, lifespan | kiểm tra có `FastAPI(...)`, `create_app()`, `include_router(...)` | chỉ thêm health route nếu chưa có và include audio router vào cuối wiring |
| `backend/app/api/router.py` hoặc router gốc | append | High | file trung tâm, dễ conflict import/router order | kiểm tra pattern `APIRouter()` + `include_router` | thêm import audio subrouters + include_router cuối file |
| `backend/app/api/*.py` (mới cho audio) | create new | Low | namespace mới, ít đụng code cũ | kiểm tra trùng tên route file | tạo file mới, không sửa route cũ |
| `backend/app/core/config.py` | append | Medium | repo thật thường đã có settings class | kiểm tra Pydantic settings hiện tại | chỉ thêm audio env vars vào settings đang có |
| `backend/app/core/storage.py` | append or skip | Medium | nếu repo đã có storage abstraction thì không được fork logic | kiểm tra đã có S3/MinIO helper chưa | nối audio vào storage hiện có, không tạo layer song song |
| `backend/app/db/base.py` | append | Medium | import model registry để Alembic thấy model | kiểm tra metadata/Base hiện tại | chỉ thêm import model audio vào registry hiện có |
| `backend/app/db/session.py` | skip unless missing | Medium | session factory thường đã tồn tại | kiểm tra session dependency hiện tại | ưu tiên reuse session cũ |
| `backend/app/models/__init__.py` | append | Low | registry export | kiểm tra pattern import model | thêm export audio models |
| `backend/app/models/*.py` (audio) | create new | Low | bounded context mới | kiểm tra naming collision | tạo mới |
| `backend/app/schemas/*.py` (audio) | create new | Low | bounded context mới | kiểm tra naming collision | tạo mới |
| `backend/app/repositories/*.py` (audio) | create new | Low | bounded context mới | kiểm tra pattern repo layer | tạo mới hoặc fold vào repo style hiện tại |
| `backend/app/services/provider_router.py` | create new or append existing router | Medium | nếu repo đã có provider abstraction khác | kiểm tra provider strategy hiện tại | dùng adapter/wrapper, tránh bypass core hiện có |
| `backend/app/services/*.py` (audio) | create new | Low | domain mới | kiểm tra DI pattern | tạo mới theo style repo |
| `backend/app/providers/*.py` | create new | Low | isolated adapter layer | kiểm tra naming collision | tạo mới |
| `backend/app/workers/celery_app.py` | append or skip | High | repo có thể đã có Celery app duy nhất | kiểm tra Celery instance hiện tại | reuse celery app cũ, chỉ register tasks audio |
| `backend/app/workers/*.py` | create new | Medium | task module mới nhưng phải dùng queue conventions cũ | kiểm tra naming/queue config | tạo mới, import vào celery discovery |
| `backend/app/api/deps.py` | append | Medium | dependency injection/auth/session | kiểm tra deps hiện có | thêm getter cho audio services, không thay deps cũ |
| `alembic/env.py` | append | High | dễ vỡ migration runtime | kiểm tra target_metadata và import path | chỉ chắc chắn model audio được import vào Base, tránh sửa flow env.py nếu không cần |
| `alembic/versions/*` | create new migration | Medium | topology migration | kiểm tra có single head không | tạo migration mới sau khi import model audio ổn |
| `tests/` | create new | Low | isolated smoke tests | kiểm tra pytest structure | thêm smoke tests audio riêng |
