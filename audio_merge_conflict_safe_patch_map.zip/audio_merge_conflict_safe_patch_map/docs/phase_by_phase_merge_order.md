# Phase-by-Phase Merge Order

## Phase 0 — Repo scan
- xác định entrypoint ASGI
- xác định router aggregator
- xác định settings file
- xác định DB Base/session
- xác định Celery app hiện có
- xác định Alembic topology hiện tại

## Phase 1 — Create-only files (an toàn nhất)
Tạo mới mà gần như không conflict:
- `backend/app/api/tts.py`
- `backend/app/api/conversation.py`
- `backend/app/api/voice_clone.py`
- `backend/app/api/voices.py`
- `backend/app/api/projects.py`
- `backend/app/api/jobs.py`
- `backend/app/api/billing.py`
- `backend/app/api/providers.py`
- `backend/app/models/*.py` (audio)
- `backend/app/schemas/*.py` (audio)
- `backend/app/repositories/*.py` (audio)
- `backend/app/services/*.py` (audio)
- `backend/app/providers/*.py`
- `backend/app/workers/audio_tasks.py`
- `backend/app/workers/clone_tasks.py`
- `backend/app/utils/*.py`

## Phase 2 — Low-risk append
- `backend/app/models/__init__.py`
- `backend/app/db/base.py`
- `backend/app/core/config.py`

## Phase 3 — Controlled wiring
- router aggregator
- `api/deps.py`
- `main.py`

## Phase 4 — Worker integration
- Celery task discovery
- queue names
- retry policy

## Phase 5 — Migration
- generate migration
- verify single head
- upgrade staging DB

## Phase 6 — Smoke verify
- compile
- import app
- openapi route list
- create one fake TTS job
- run one worker task dry run
