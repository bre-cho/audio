# Verify Checklist

## After Phase 1
- `python -m compileall backend/app`
- import thử các module audio mới

## After Phase 2
- kiểm tra app settings load được env mới
- kiểm tra Base import đủ audio models

## After Phase 3
- in route list / openapi xem đã có:
  - `/api/v1/tts/*`
  - `/api/v1/conversation/*`
  - `/api/v1/voice-clone/*`
  - `/api/v1/voices/*`
  - `/api/v1/projects/*`
  - `/api/v1/jobs/*`
  - `/api/v1/billing/*`

## After Phase 4
- worker import task audio không lỗi
- queue discovery nhìn thấy task modules mới

## After Phase 5
- `alembic heads` còn 1 head
- `alembic upgrade head` chạy sạch

## After Phase 6
- GET `/healthz` = 200
- generate fake TTS job = 200/202
- job status endpoint trả về schema đúng
