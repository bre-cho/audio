# Manual Conflict Resolution Rules

## Global rules
1. Không overwrite file cũ nguyên khối nếu file đó đã tồn tại trong repo đích.
2. Ưu tiên append block nhỏ, có comment marker `# audio-ai patch start/end`.
3. Nếu repo có pattern khác skeleton, giữ pattern repo thật và port logic audio vào pattern đó.
4. Một repo chỉ có **một** app factory, **một** DB Base/session chain, **một** Celery app chính.
5. Nếu xuất hiện 2 abstraction song song cho cùng một việc, bỏ abstraction mới và cấy logic vào abstraction cũ.

## Router conflicts
- Nếu import line quá dài hoặc dùng lazy import, giữ style repo hiện tại.
- Nếu router prefix đã là `/api/v1`, đừng lặp prefix ở subrouter.

## Model conflicts
- Nếu repo đã có `TimestampMixin`, `UUIDMixin`, `SoftDeleteMixin`, dùng mixin cũ.
- Nếu naming snake_case/plural khác skeleton, ưu tiên convention repo.

## Service conflicts
- Nếu repo đang dùng use-case/interactor thay vì service, port code sang layer đó.
- Không để route gọi repository trực tiếp nếu repo đang có service layer.

## Worker conflicts
- Không set queue name mới phá monitoring hiện tại.
- Nếu repo có decorator/task base riêng, dùng base cũ.

## Alembic conflicts
- Nếu nhiều head: merge topology trước, rồi mới thêm audio migration.
- Không sửa import path trong `env.py` khi chưa hiểu lý do repo cũ đang vận hành.
