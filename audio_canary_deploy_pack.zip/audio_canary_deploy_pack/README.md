# Audio Canary Deploy + Auto Traffic Shift Pack

Bộ này thêm một lớp canary deploy riêng cho audio pipeline, theo hướng ít đụng flow deploy/render hiện có của repo.

## Thành phần
- `.github/workflows/audio-canary-deploy.yml`
- `scripts/deploy/canary_deploy.sh`
- `scripts/deploy/audio_shift_traffic.sh`
- `scripts/deploy/post_canary_audio_smoke.sh`
- `scripts/deploy/rollback_canary.sh`
- `docs/AUDIO_CANARY_DEPLOY_PATCH.md`
- `docs/ENV_AND_SECRETS.md`
- `docs/ROLLBACK_AND_SHIFT_POLICY.md`

## Ý tưởng chính
1. Chỉ deploy canary cho audio-capable service/revision.
2. Chạy smoke test audio thật trên canary.
3. Shift traffic tăng dần: 5% -> 25% -> 50% -> 100%.
4. Fail ở bất kỳ nấc nào thì rollback về stable revision.
5. Gửi alert qua Slack và upload artifact/log.

## Cách dùng nhanh
```bash
bash scripts/deploy/canary_deploy.sh
bash scripts/deploy/post_canary_audio_smoke.sh
bash scripts/deploy/audio_shift_traffic.sh 5
```

## Môi trường giả định
Pack này không khóa cứng platform, nhưng mặc định hỗ trợ pattern revision-based rất hợp với:
- Cloud Run
- ECS/ALB weighted target groups
- NGINX/Traefik/caddy behind a deploy hook

Bạn chỉ cần map 4 lệnh thật:
- `CANARY_DEPLOY_COMMAND`
- `SHIFT_TRAFFIC_COMMAND`
- `ROLLBACK_COMMAND`
- `FETCH_STABLE_COMMAND`
