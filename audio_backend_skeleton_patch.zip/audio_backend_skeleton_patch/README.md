# Audio AI Backend Skeleton Patch

Repo-ready backend skeleton for an audio AI platform modeled after the earlier GENSUITE++ spec pack.

## What is included
- FastAPI route skeletons
- Pydantic request/response schemas
- SQLAlchemy model skeletons
- provider abstraction layer
- Celery worker placeholders
- service layer wiring
- repository layer stubs
- `.env.example`

## What is intentionally not included
- production credentials
- provider-specific private SDK logic
- full auth implementation
- payment gateway implementation
- complete migration history

## Suggested drop-in path
Assumes a monorepo path similar to:

```text
backend/app/
  api/
  core/
  db/
  models/
  repositories/
  schemas/
  services/
  providers/
  workers/
  utils/
```

## Merge rule
Add files first, then wire them into your existing app gradually:
1. `core`, `db`, `models`, `schemas`
2. `repositories`, `providers`, `services`
3. `api`
4. `workers`
5. app router registration

## Minimal verify checklist
- app boots
- `/healthz` returns 200
- `/api/v1/providers` returns configured providers
- `/api/v1/voices` returns empty list or seeded list
- queue submit endpoints create `audio_jobs`
